﻿using Birds.Models;
using Microsoft.Toolkit.Mvvm.ComponentModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Birds.ViewModels
{
    [ObservableObject]
    public partial class BirdsViewModel
    {
        [ObservableProperty]
        private BirdRepository birdRepository;
        [ObservableProperty]
        private Bird? current;
        public BirdsViewModel(BirdRepository birdRepository)
        {
            this.birdRepository = birdRepository;
            Current = birdRepository.Birds.FirstOrDefault();
        }
    }
}
